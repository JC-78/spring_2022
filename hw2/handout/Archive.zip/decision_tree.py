import sys
import numpy as np
import math
import copy

class Node:
    '''
    Here is an arbitrary Node class that will form the basis of your decision
    tree. 
    Note:
        - the attributes provided are not exhaustive: you may add and remove
        attributes as needed, and you may allow the Node to take in initial
        arguments as well
        - you may add any methods to the Node class if desired 
    '''
    def __init__(self,data,attr=None,depth=0,used=set()):
        self.left = None
        self.right = None
        self.vote = None
        self.data=data
        self.attr=attr
        self.depth=depth
        self.used=used
        self.child=dict()
        
def read_data(input_file):
    """
    reads data and returns 
    1)data in dictionary format 
    2)attributes and their order
    """
    with open(input_file, 'r') as data:
        data=[line.split() for line in data]  
    k=data[0]  #first row
    column_count = len(k)
    features = dict()
    features[-1] = k[column_count-1] #labels
    data1 = dict()
    for feature in k:
        data1[feature] = []
    for r in data[1:]:
        for c in range(column_count):
            features[k[c]] = c #attribute column order number
            data1[k[c]].append(r[c])
    #print(data1)
    #print(attributes)
    return (data1, features)

def majority(data,label):
    """
    gets the MajorityVoteItem in the dataset 
    """
    d=dict()
    for item in data[label]:
        if item not in d:
            d[item]=1
        else:
            d[item]+=1
    maxItem="NA"
    maxCount=-1
    for item in d:
        if d[item]>maxCount:
            maxItem=item
            maxCount=d[item]
        elif d[item]==maxCount:
            a=maxItem[0]
            b=item[0]
            if a<b:
                maxItem=item
    return maxItem,maxCount

def entropy_help(labels,feature=None):
    length=len(labels)
    label_values=set(labels)
    if length==0 or len(label_values)==1:
        return 0
    if feature!=None:
        #conditional entropy
        label_values=set(feature)
        label_tmp=labels
        labels=feature
        feature=label_tmp
    d=dict()
    for item in label_values:
        d[item]=[]
    count=0
    for i in range(length):
        label=labels[i]
        if feature:
            d[label].append(feature[i])
        else:
            d[label].append(label)
        count+=1
    res=0
    for label in d:
        entropy=0
        p=len(d[label])/count
        if p!=0:
            entropy=p*math.log(p, 2)*-1
        if feature:
            entropy1=entropy_help(d[label])
            entropy=p*entropy1
        res+=entropy
    return res

def MI_help(data, label, feature):
    entropy1=entropy_help(data[label], data[feature])
    entropy2=entropy_help(data[label])
    res=entropy2-entropy1
    return res

def createDecisionTree(data,data_attributes,max_depth,depth=0,used=set()):
    label=data_attributes[-1]
    #base case
    if max_depth==0:
        ans=Node(copy.deepcopy(data),label,depth, used)
        ans.vote,vote_count=majority(data,label)
        return ans 

    best_split=None
    MI_max=-1
    for feature in data:
        if feature!=label:
            MI=MI_help(data, label, feature)
        if MI>0 and MI>MI_max:
            MI_max=MI
            best_split=feature 
        elif MI>0 and MI_max==MI:
            #If tied, then split on the first column to break ties
            if data_attributes[feature]<data_attributes[best_split]: 
                best_split=feature

    depth_limit=False
    attribute_limit=False
    if max_depth==depth:
        depth_limit=True
    if len(used)==(len(data)-1):
        attribute_limit=True
    if depth_limit or attribute_limit or not best_split:
        leaf_node=Node(copy.deepcopy(data),label,depth, used)
        leaf_node.vote,vote_count1=majority(data,label)
        return leaf_node

    attribute_values=set(data[best_split])
    partitioned_data=dict()
    length=len(data[best_split])
    for value in attribute_values:
        partitioned_data[value]=dict()
        for feature in data:
            partitioned_data[value][feature]=[]
    for i in range(length):
        item=data[best_split][i]
        for feature in data:
            partitioned_data[item][feature].append(data[feature][i])
    
    new_used=used.copy()
    new_used.add(best_split)
    res_tree=Node(copy.deepcopy(data),best_split,depth, new_used)
    new_depth=depth+1
    #print("best split is", best_split)
    #print("attribute values of the best split are", attribute_values)
    #print("data length is", len(data)-1)
    #print("partitioned data length is",len(partitioned_data)-1)
    #print("used attribute length is", len(used))
    for item in partitioned_data:
        data1 = copy.deepcopy(partitioned_data[item])
        res_tree.child[item]=createDecisionTree(data1, data_attributes, max_depth, new_depth, new_used)
    return res_tree

def printDT(tree, label_name, labels, depth = 0):
    count=len(tree.data[label_name])
    maxItem, maxCount=majority(tree.data,label_name)
    s='['
    for label in labels:
        if label!=maxItem:
            val=count-maxCount
            s+=str(val)+' '+label+'/'
        else:
            s+=str(maxCount)+' '+label+'/'            
    s=s[:-1]+']'
    print(s)

    if not tree.vote:
        new_depth=depth+1
        tmp=('| ' * new_depth)+tree.attr+' = '
        values = list(tree.child.keys())
        for value in values:
            s=tmp+value+':'
            print(s, end = " ")
            new=tree.child[value]
            printDT(new, label_name, labels, new_depth)

def predict(model, data):
    if model.vote:
        return model.vote
    new_model=model.child[data[model.attr]]
    return predict(new_model,data)

def test(DT,data,labels):
    length=len(labels)
    error=0
    pred=np.array([])
    for i in range(length):
        d=dict()
        for feature in data:
            d[feature]=data[feature][i]
        guess=predict(DT,d)
        np.append(pred,guess)
        if guess!=labels[i]:
            error+=1
    res=error/length
    return (pred,res)

def metric_output(name,train_error,test_error):
    res="error(train): "+str(train_error)+"\n"
    res+="error(test): "+str(test_error)+"\n"
    with open(name, 'w') as out:
        out.write(res)

def output(output_file, preds):
    item = ''
    for pred in preds:
        item += pred + '\n'
    item = item.strip()
    with open(output_file, 'w') as res:
        res.write(item)

if __name__ == '__main__':
    train_input=sys.argv[1]
    train_data,train_attributes=read_data(train_input)
    max_depth=sys.argv[3]
    classifier=createDecisionTree(train_data,train_attributes,max_depth)

    test_input=sys.argv[2]
    test_data,test_attributes=read_data(test_input)
    label_name=train_attributes[-1]
    train_labels=train_data[label_name]
    labels=list(set(train_labels))
    labels.sort()

    #print("label_name is: ",label_name)
    #print("labels are: ",labels)
    printDT(classifier, label_name,labels)

    test_labels=test_data[test_attributes[-1]]
    train_pred, train_error=test(classifier, train_data, train_labels)
    test_pred, test_error=test(classifier, test_data, test_labels)
    #print("train error is",train_error)
    #print("test error is", test_error)
    metrics_out=sys.argv[6]
    
    metric_output(metrics_out,train_error,test_error)
    train_out=sys.argv[4]
    test_out=sys.argv[5]
    output(train_out,train_pred)
    output(test_out,test_pred)
